---------------- CONSTRAINT SATISFACTION PROBLEMS -----------------

Copy and paste in terminal (relative to the path of the file) 
python3 csp.py (to do simple bactracking search)
python3 csp.py --variableSelection mrv --orderValues lrv --inference mac (to add inference and variable/value selection methods)
python3 csp.py -v mrv -o lrv -i mac (to add inference and variable/value selection methods in a simplyfied way)

The program requires:
-Python3
-Pygame

Once you can see the graph, press space to continue the execution of the Backtracking Search
