Execute: python mdp.py
Dependencies: pygame

Enter to mdp.by and uncomment the section of code corresponding to value iteration or policy iteration. 

To see how values change, press space in every iteration.

