import pygame
import sys, getopt
import numpy as np
import time

#Constants
size_win_x = 720
size_win_y = 560
size_win_y2 = 488
red = (255,0,0)
green = (0,255,0)
blue = (0,0,255)
white = (255,255,255)
black = (0,0,0)
rgb = [red,green,blue]

screen = []
myfont = []
coord = {}
for x in range(0,4):
	for y in range(0,3):
		s = (x,2-y)
		c = ((size_win_x/4)*(x+0.5), (size_win_y2/3)*(y+0.7))
		coord[s] = c
#print(coord)


def wait():
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                pygame.sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            	return

def update_values(utilities, policy, iter):
	global screen, myfont
	pygame.init()
	pygame.display.set_caption('GridWorld')
	screen = pygame.display.set_mode((size_win_x,size_win_y))
	image = pygame.image.load("grid.png")
	screen.blit(image, [0, 0])	
	pygame.font.init()
	myfont = pygame.font.SysFont('Arial', 50)	
	for s in utilities.keys():
		draw_text(utilities[s],s)
		draw_actions(policy[s],s)
	pygame.display.update()
	wait()

def draw_text(u,s):
	global screen, myfont
	textsurface = myfont.render(str(round(u, 2)), True, black)
	textRect = textsurface.get_rect()    
	textRect.center = coord[s]
	screen.blit(textsurface, textRect)  

def draw_actions(pi,s):
	global screen, myfont
	action = ""
	if pi == (1,0):
		action = u"\u25B6"
	if pi == (-1,0):
		action = u"\u25C0"
	if pi == (0,1):
		action = u"\u25B2"
	if pi == (0,-1):
		action = u"\u25BC"
	textsurface = myfont.render(action, True, black)
	textRect = textsurface.get_rect()    
	textRect.center = (coord[s][0],coord[s][1]-65.08)
	screen.blit(textsurface, textRect)    






# utilities = {(0,0):1, (0,1):2, (0,2):3}
# policy = {(0,0):(0,1), (0,1):(0,1), (0,2):None}
# update_values(utilities, policy, 1)